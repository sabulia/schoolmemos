import React from "react";
import { renderToStaticMarkup } from "react-dom/server";
import ReactMarkdown from "react-markdown";
import rehypeKatex from "rehype-katex";
import rehypeRaw from "rehype-raw";
import rehypeSanitize from "rehype-sanitize";
import remarkGfm from "remark-gfm";
import { describe, expect, it } from "vitest";
import { isTrustedIframeSrc, memoUrlTransform, SANITIZE_SCHEMA } from "@/components/MemoContent/constants";
import { remarkCurrencySafeMath } from "@/utils/remark-plugins/remark-currency-safe-math";

type IframeProps = React.ComponentProps<"iframe">;

const TrustedIframe = (props: IframeProps) => {
  if (typeof props.src !== "string" || !isTrustedIframeSrc(props.src)) {
    return null;
  }
  return <iframe {...props} />;
};

const renderMemoContent = (content: string): string =>
  renderToStaticMarkup(
    <ReactMarkdown
      remarkPlugins={[remarkCurrencySafeMath]}
      rehypePlugins={[rehypeRaw, [rehypeSanitize, SANITIZE_SCHEMA], [rehypeKatex, { throwOnError: false, strict: false }]]}
      components={{ iframe: TrustedIframe }}
    >
      {content}
    </ReactMarkdown>,
  );

const renderGfmContent = (content: string): string =>
  renderToStaticMarkup(
    <ReactMarkdown remarkPlugins={[remarkGfm]} rehypePlugins={[[rehypeSanitize, SANITIZE_SCHEMA]]} urlTransform={memoUrlTransform}>
      {content}
    </ReactMarkdown>,
  );

describe("memo content sanitization", () => {
  it("strips user-controlled inline styles from raw HTML spans", () => {
    const html = renderMemoContent('<span style="position:fixed;inset:0;z-index:99999">overlay</span>');

    expect(html).toMatch(/<span>overlay<\/span>/);
    expect(html).not.toMatch(/style=/);
    expect(html).not.toMatch(/position:fixed/);
  });

  it("still renders KaTeX output after sanitizing math marker classes", () => {
    const html = renderMemoContent("$L$");

    expect(html).toMatch(/class="katex"/);
    expect(html).toMatch(/class="katex-html"/);
  });

  it("keeps tel: and sms: link targets", () => {
    const html = renderGfmContent("[phone me](tel:+440000000000) [text me](sms:+440000000000?body=hi)");

    expect(html).toContain('href="tel:+440000000000"');
    expect(html).toContain('href="sms:+440000000000?body=hi"');
  });

  it("still strips script-capable link targets", () => {
    const html = renderGfmContent("[x](javascript:alert(1)) [y](data:text/html,hi) [z](vbscript:msgbox)");

    expect(html).not.toMatch(/javascript:/);
    expect(html).not.toMatch(/data:/);
    expect(html).not.toMatch(/vbscript:/);
    expect(html).toMatch(/<a>x<\/a>/);
  });

  it("preserves checked state for GFM task list items", () => {
    const html = renderGfmContent("- [x] Done\n- [ ] Todo");
    const inputs = html.match(/<input[^>]+\/>/g) ?? [];

    expect(inputs).toHaveLength(2);
    expect(inputs[0]).toContain('checked=""');
    expect(inputs[1]).not.toContain('checked=""');
  });
});

describe("trusted iframe providers", () => {
  it("accepts trusted providers only", () => {
    expect(isTrustedIframeSrc("https://www.youtube.com/embed/abc123")).toBe(true);
    expect(isTrustedIframeSrc("https://www.youtube-nocookie.com/embed/abc123?si=test")).toBe(true);
    expect(isTrustedIframeSrc("https://player.vimeo.com/video/123456")).toBe(true);
    expect(isTrustedIframeSrc("https://open.spotify.com/embed/track/123456")).toBe(true);
    expect(isTrustedIframeSrc("https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/123456")).toBe(true);
    expect(isTrustedIframeSrc("https://www.loom.com/embed/123456")).toBe(true);
    expect(isTrustedIframeSrc("https://www.google.com/maps/embed?pb=test")).toBe(true);
    expect(isTrustedIframeSrc("https://app.diagrams.net/?embed=1")).toBe(true);
    expect(isTrustedIframeSrc("https://www.draw.io/?embed=1")).toBe(true);
    expect(isTrustedIframeSrc("https://evil.example/embed/abc123")).toBe(false);
  });

  it("drops picture sources that would bypass the https-only image rule", () => {
    const html = renderMemoContent(
      '<picture><source srcset="http://tracker.example/a.png"><img src="https://img.example/a.png"></picture>',
    );

    expect(html).not.toMatch(/<picture/);
    expect(html).not.toMatch(/<source/);
    expect(html).not.toMatch(/tracker\.example/);
    expect(html).toMatch(/img\.example\/a\.png/);
  });

  it("drops untrusted iframe embeds during rendering", () => {
    const trusted = renderMemoContent('<iframe src="https://www.youtube.com/embed/abc123" title="demo"></iframe>');
    const untrusted = renderMemoContent('<iframe src="https://evil.example/embed/abc123" title="demo"></iframe>');

    expect(trusted).toMatch(/<iframe/);
    expect(trusted).toMatch(/youtube\.com\/embed\/abc123/);
    expect(untrusted).not.toMatch(/<iframe/);
  });
});
