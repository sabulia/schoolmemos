import { createBrowserRouter, Navigate, type RouteObject, useLocation } from "react-router-dom";
import App from "@/App";
import { ChunkLoadErrorFallback } from "@/components/ErrorBoundary";
import { useAuth } from "@/contexts/AuthContext";
import useCurrentUser from "@/hooks/useCurrentUser";
import MainLayout from "@/layouts/MainLayout";
import RootLayout from "@/layouts/RootLayout";
import { lazyWithReload } from "@/utils/lazy";
import { RequireAuthRoute, RequireFullInitializationRoute, RequireGuestRoute, RequireInstanceInitializationRoute } from "./guards";
import { LegacyProfileRedirect } from "./LegacyProfileRedirect";
import { CALENDAR_ROUTE_PATTERN, getCollectionCreator, ROUTES, SPACE_ROUTE_PATTERN, withCollectionCreator } from "./routes";
import { SpaceRoute } from "./SpaceRoute";

const AdminSignIn = lazyWithReload(() => import("@/pages/AdminSignIn"));
const About = lazyWithReload(() => import("@/pages/About"));
const Archived = lazyWithReload(() => import("@/pages/Archived"));
const AuthCallback = lazyWithReload(() => import("@/pages/AuthCallback"));
const MemoMap = lazyWithReload(() => import("@/pages/Map"));
const Calendar = lazyWithReload(() => import("@/pages/Calendar"));
const Home = lazyWithReload(() => import("@/pages/Home"));
const Inboxes = lazyWithReload(() => import("@/pages/Inboxes"));
const MemoDetail = lazyWithReload(() => import("@/pages/MemoDetail"));
const NotFound = lazyWithReload(() => import("@/pages/NotFound"));
const PermissionDenied = lazyWithReload(() => import("@/pages/PermissionDenied"));
const Attachments = lazyWithReload(() => import("@/pages/Attachments"));
const Setting = lazyWithReload(() => import("@/pages/Setting"));
const MemoViews = lazyWithReload(() => import("@/pages/MemoViews"));
const SignIn = lazyWithReload(() => import("@/pages/SignIn"));
const SignUp = lazyWithReload(() => import("@/pages/SignUp"));
// 校园版页面（本项目新增）
const CampusFriends = lazyWithReload(() => import("@/campus/pages/FriendsPage"));
const CampusGroups = lazyWithReload(() => import("@/campus/pages/GroupsPage"));
const CampusCircle = lazyWithReload(() => import("@/campus/pages/CirclePage"));
const CampusTopics = lazyWithReload(() => import("@/campus/pages/TopicsPage"));
const CampusRecommend = lazyWithReload(() => import("@/campus/pages/RecommendPage"));
const CampusThemes = lazyWithReload(() => import("@/campus/pages/ThemesPage"));
const CampusMine = lazyWithReload(() => import("@/campus/pages/MinePage"));
const CampusSearch = lazyWithReload(() => import("@/campus/pages/SearchPage"));
const CampusAuth = lazyWithReload(() => import("@/campus/pages/CampusAuthPage"));

const HomeRoute = () => {
  const { isIdentityInitialized } = useAuth();
  const currentUser = useCurrentUser();
  const location = useLocation();
  if (!isIdentityInitialized) return null;
  if (!currentUser && !getCollectionCreator(location.search)) {
    return <Navigate to={{ pathname: ROUTES.EXPLORE, search: location.search, hash: location.hash }} replace />;
  }
  return <Home />;
};

const ExploreRoute = () => {
  const location = useLocation();
  const search = withCollectionCreator(location.search);
  if (search !== location.search) return <Navigate to={{ pathname: location.pathname, search, hash: location.hash }} replace />;
  return <Home />;
};

// Backward compatibility alias.
export const Routes = ROUTES;
export { ROUTES };

/**
 * Static route configuration. Exported so tests can assert on the tree shape
 * (e.g. that `/auth/callback` stays outside the guest-only guard subtree) and
 * so integration tests can drive a `createMemoryRouter` over the same tree.
 */
export const routeConfig: RouteObject[] = [
  {
    path: "/",
    element: <App />,
    errorElement: <ChunkLoadErrorFallback />,
    children: [
      {
        path: Routes.AUTH,
        children: [
          // The OAuth callback must run regardless of the current session — an
          // authenticated tab elsewhere must not block it from consuming its
          // one-time OAuth state. Keep it outside the guest-only subtree.
          { path: "callback", element: <AuthCallback /> },
          {
            element: <RequireInstanceInitializationRoute />,
            children: [
              {
                element: <RequireGuestRoute />,
                children: [
                  { path: "", element: <SignIn /> },
                  { path: "admin", element: <AdminSignIn /> },
                  { path: "signup", element: <SignUp /> },
                ],
              },
            ],
          },
        ],
      },
      // Backward compatibility: the old `/home` URL now lives at `/`.
      { path: "home", element: <Navigate to={Routes.HOME} replace /> },
      // 校园版注册 / 找回密码（无需登录）。
      { path: "campus/auth", element: <CampusAuth /> },
      {
        element: <RootLayout />,
        children: [
          {
            element: <MainLayout />,
            children: [
              { index: true, element: <HomeRoute /> },
              {
                element: <RequireInstanceInitializationRoute />,
                children: [{ path: Routes.ABOUT, element: <About /> }],
              },
              { path: Routes.EXPLORE, element: <ExploreRoute /> },
              // Like Timeline, the calendar is public: guests see the memos readable to them.
              { path: CALENDAR_ROUTE_PATTERN, element: <Calendar /> },
              { path: Routes.USER_PROFILE, element: <LegacyProfileRedirect /> },
              {
                element: <RequireAuthRoute />,
                children: [
                  { path: Routes.ARCHIVED, element: <Archived /> },
                  // 校园版七大功能分区（本项目新增）。
                  { path: "campus", element: <Navigate to="/campus/circle" replace /> },
                  { path: "campus/friends", element: <CampusFriends /> },
                  { path: "campus/groups", element: <CampusGroups /> },
                  { path: "campus/circle", element: <CampusCircle /> },
                  { path: "campus/topics", element: <CampusTopics /> },
                  { path: "campus/recommend", element: <CampusRecommend /> },
                  { path: "campus/themes", element: <CampusThemes /> },
                  { path: "campus/mine", element: <CampusMine /> },
                  { path: "campus/search", element: <CampusSearch /> },
                  {
                    element: <RequireFullInitializationRoute />,
                    children: [{ path: Routes.VIEWS, element: <MemoViews /> }],
                  },
                ],
              },
            ],
          },
          { path: "memos/:uid", element: <MemoDetail /> },
          { path: "memos/shares/:token", element: <MemoDetail /> },
          {
            element: <RequireFullInitializationRoute />,
            children: [{ path: Routes.MAP, element: <MemoMap /> }],
          },
          {
            element: <RequireAuthRoute />,
            children: [
              {
                element: <RequireFullInitializationRoute />,
                children: [
                  {
                    path: SPACE_ROUTE_PATTERN,
                    children: [
                      {
                        element: <SpaceRoute />,
                        children: [
                          {
                            element: <MainLayout />,
                            children: [
                              { index: true, element: <HomeRoute /> },
                              { path: "explore", element: <ExploreRoute /> },
                              { path: "calendar/:year?/:month?/:day?", element: <Calendar /> },
                            ],
                          },
                          { path: "attachments", element: <Attachments /> },
                          { path: "map", element: <MemoMap /> },
                        ],
                      },
                      { path: "*", element: <NotFound /> },
                    ],
                  },
                  { path: Routes.ATTACHMENTS, element: <Attachments /> },
                  { path: Routes.INBOX, element: <Inboxes /> },
                  { path: Routes.SETTING, element: <Setting /> },
                ],
              },
            ],
          },
          { path: "403", element: <PermissionDenied /> },
          { path: "404", element: <NotFound /> },
          { path: "*", element: <NotFound /> },
        ],
      },
    ],
  },
];

const router = createBrowserRouter(routeConfig);

export default router;
